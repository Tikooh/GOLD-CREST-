import matplotlib.pyplot as plt
import numpy as np
import pickle
DIST = 100
WRITE = False

class drone:
    def __init__(self, x, y,time):
        self.x = x
        self.y = y
        self.time = time



def write_list(a_list,name):
    with open(f'{name}', 'wb') as fp:
        pickle.dump(a_list, fp)

def read_list(name):
    with open(f'{name}', 'rb') as fp:
        n_list = pickle.load(fp)
        return n_list


def predict(drone1,drone2,drone3,reqtime):
    ttime = drone3.time-drone1.time
    v1,v2,v3 = np.array([drone1.x,drone1.y]),np.array([drone2.x,drone2.y]),np.array([drone3.x,drone3.y])
    if (v2-v1)[0]**2 + (v2-v1)[1]**2 <= DIST**2 and (v3-v2)[0]**2 + (v3-v2)[1]**2 <= DIST**2:
        vf = (v2-v1)*(drone2.time-drone1.time)/ttime+(v3-v2)*(drone3.time-drone2.time)/ttime
        final = list(vf*reqtime + v3)
        return final[0],final[1],drone3.time+reqtime
    else:
        return None,None,None
if __name__ == "__main__":
    xlist = read_list("xlist")
    ylist = read_list("ylist")
    tlist = read_list("tlist")
    locationList = [drone(xlist[i],ylist[i],tlist[i]) for i in range(len(xlist))]
    plt.plot()
    plt.scatter(xlist,ylist)
    plt.plot(xlist,ylist)
    for x,y,t in zip(xlist,ylist,tlist):
        label = f"drone {t}"
        plt.annotate(label,(x,y),textcoords="offset points",xytext=(0,10),ha='center')
    predictionsx = []
    predictionsy = []
    predictionstimes = []
    for i in range(len(locationList)-3):
        x,y,time=predict(locationList[i],locationList[i+1],locationList[i+2],1)
        if x!= None:
            predictionsx.append(x) 
            predictionsy.append(y) 
            predictionstimes.append(time)
    plt.scatter(predictionsx,predictionsy)
    plt.plot(predictionsx,predictionsy)
    for x1,y1,t1 in zip(predictionsx,predictionsy,predictionstimes):
        label = f"prediction {t1}"
        plt.annotate(label,(x1,y1),textcoords="offset points",xytext=(0,10),ha='center')
    plt.show()